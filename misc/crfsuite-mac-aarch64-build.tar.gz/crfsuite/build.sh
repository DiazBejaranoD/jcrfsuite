#!/bin/sh
cd liblbfgs-1.10
make clean && ./configure --prefix=$PWD/../pseudo-install-dir && make install
cd ../crfsuite-0.12
make clean && ./configure --prefix=$PWD/../pseudo-install-dir --with-liblbfgs=$PWD/../pseudo-install-dir --disable-sse2 && make install
cd swig/java
rm *.so *.o
g++ -fno-strict-aliasing -DNDEBUG -g -fwrapv -O2 -Wall -Wstrict-prototypes -fPIC -I$PWD/../../../pseudo-install-dir/include -I$JAVA_HOME/include -I$JAVA_HOME/include/darwin -c export_wrap.cpp -o export_wrap.o
g++ -fno-strict-aliasing -DNDEBUG -g -fwrapv -O2 -Wall -Wstrict-prototypes -fPIC -I$PWD/../../../pseudo-install-dir/include -I$JAVA_HOME/include -c crfsuite.cpp -o crfsuite.o
g++ crfsuite.o export_wrap.o ../../../liblbfgs-1.10/lib/.libs/*.o ../../../crfsuite-0.12/lib/cqdb/.libs/*.o ../../../crfsuite-0.12/lib/crf/.libs/libcrfsuite*.o -o libcrfsuite.dylib -shared

cp libcrfsuite.dylib ../../../
cd ../../../
